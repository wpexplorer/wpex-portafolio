<?php
// Redirect single featured home
wp_redirect( esc_url( home_url( '/' ) ), 301 ); ?>