<?php
// Redirect single slides home
wp_redirect( esc_url( home_url( '/' ) ), 301 ); ?>